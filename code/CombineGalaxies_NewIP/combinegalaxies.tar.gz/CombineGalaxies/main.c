/* code to combine two galaxies such that they collide
 * on a parabolic encounter 
 *
 * written by V. Springel, MPA
 */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "globvars.h"




int main(int argc, char *argv[])
{
  double theta1, phi1, theta2, phi2;
  double rmin, rstart;
  char gal_fname1[100], gal_fname2[100], gal_output[100];

  if(argc != 10)
    {
      printf("\nwrong number of arguments\n");
      printf
	("call with:\n\n<fname_gal1> <theta1> <phi1>\n<fname_gal2> <theta2> <phi2>\n<rmin> <rstart>\n<fname_galout>\n\n");
      printf("(angles in degrees.)\n\n");
      exit(0);
    }

  strcpy(gal_fname1, argv[1]);
  theta1 = atof(argv[2]);
  phi1 = atof(argv[3]);

  strcpy(gal_fname2, argv[4]);
  theta2 = atof(argv[5]);
  phi2 = atof(argv[6]);

  rmin = atof(argv[7]);
  rstart = atof(argv[8]);

  strcpy(gal_output, argv[9]);


  load_particles(gal_fname1, &gal[0], &header[0]);
  load_particles(gal_fname2, &gal[1], &header[1]);

  turn_galaxy(&gal[0], theta1, phi1);
  turn_galaxy(&gal[1], theta2, phi2);


  move_galaxies(&gal[0], &gal[1], rmin, rstart);

  save_combined(gal_output, &gal[0], &gal[1]);

  return 0;
}
