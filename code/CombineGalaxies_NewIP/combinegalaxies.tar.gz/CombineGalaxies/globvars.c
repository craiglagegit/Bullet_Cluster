

#include "globvars.h"



struct galaxy_data gal[2];

struct io_header header[2];
